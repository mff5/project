    //콜백함수 (onload call back)
function call_js() {
    //모든 객체참조변수 선언
    let slideshow = document.querySelector(".slideshow");
    let slideshow_slides = document.querySelector(".slideshow_slides");
    //<a><img><a/> 배열
    let slides = document.querySelectorAll(".slideshow_slides a");

    let a_left =document.querySelector("#a_left");
    let a_right = document.querySelector("#a_right");

    let indicators = document.querySelectorAll(".indicator a");


    let timer = null;

    for (let i=0; i < slides.length; i++ ){   //이미지 배정
        let newLeft=i*100+"%";
        slides[i].style.left = newLeft;
    }


    function goToSlide(index) {             //이동
        let newLeft = index * -100 + '%';
        slideshow_slides.style.left = newLeft;
        indicators.forEach(e => {
            e.classList.remove('active');            //active 다 삭제
        })
        indicators[index].classList.add('active');
    }



    function startTimer() {               //
        index = 0;
        timer = setInterval(()=> {
            goToSlide(index);
            index += 1;
            if (index > slides.length-1)   {
                index = 0;
            }
        },3000);
    }

    startTimer();



    slideshow_slides.addEventListener("mouseenter",()=>{
        clearInterval(timer);
    });
    slideshow_slides.addEventListener("mouseleave",()=>{
        startTimer();
    });



    a_left.addEventListener("mouseenter",()=>{
        clearInterval(timer);
    });
    a_right.addEventListener("mouseleave",()=>{
        clearInterval(timer);
    });


    a_left.addEventListener("click",(e)=>{
        e.preventDefault();
        index -= 1;
        if (index < 0)  {
            index = slides.length - 1;
        }
        goToSlide(index)
    });
    a_right.addEventListener("click",(e)=>{
        e.preventDefault();
        index += 1;
        if (index > slides.length - 1)  {
            index = 0;
        }
        goToSlide(index)
    });

    indicators.forEach((e)=>{
        e.addEventListener("mouseenter",(e)=>{
            clearInterval(timer);
        });
    });

    for (let i=0;i<indicators.length;i++)   {
        indicators[i].addEventListener("click", (e)=>{
            e.preventDefault();
            goToSlide(i);
        });
    }
}
